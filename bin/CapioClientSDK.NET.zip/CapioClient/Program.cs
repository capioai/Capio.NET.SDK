﻿using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FragLabs.Audio.Codecs;
using NAudio.Wave;
using Newtonsoft.Json.Linq;
using Quobject.Collections.Immutable;
using Quobject.SocketIoClientDotNet.Client;

namespace CapioClient
{
    class Program
    {
        static void Main(string[] args)
        {
            string audioPath = args.Length != 1 ? "audio.wav" : args[0];

            ExecuteWebSocketRequest(audioPath);
        }

        private static void ExecuteWebSocketRequest(string audioPath)
        {
            ManualResetEvent resetEvent = new ManualResetEvent(false);

            var ctx = new JObject
            {
                {"sys", "GPU"},
                {"userID", "test@dev.capio.ai"},
                {"scriptID", 0},
                {"apiKey", "bafc17458780fd4f38cf4b53"},
                {"language", "en-US"},
                {"prompt", "partial"},
                {"partial", false},
                {"autostop", false},
                {"encodingType", "opus"},
                { "nlu", false},
                {"nbest", 1},
                {"pronunciation", 0}
            }.ToString();

            var context = new JObject
            {
                {"context", ctx}
            };

            var disconnect = new JObject
            {
                {"disconnect", true}
            };

            var options = new IO.Options { Transports = ImmutableList.Create("websocket") };

            var socket = IO.Socket("wss://api.capio.ai", options);

            OpusEncoder encoder = OpusEncoder.Create(16000, 1, FragLabs.Audio.Codecs.Opus.Application.Voip);

            encoder.ForwardErrorCorrection = false;
            encoder.Bitrate = 32000;

            int frameSizeInMillis = 20;
            int segmentFrames = (16000 * frameSizeInMillis) / 1000;

            int bytesPerSegment = encoder.FrameByteCount(segmentFrames);

            socket.On(Socket.EVENT_CONNECT, () =>
            {
                PrintLine("C O N N E C T");

                PrintLine("Sending context");

                socket.Send(context);

                PrintLine("Sending audio");

                using (WaveFileReader reader = new WaveFileReader(audioPath))
                {
                    int bytesRead = 0;

                    do
                    {
                        byte[] buffer = new byte[bytesPerSegment];

                        bytesRead = reader.Read(buffer, 0, buffer.Length);

                        if (bytesRead > 0)
                        {
                            int encodedLength;

                            byte[] encodedByteBuffer = encoder.Encode(buffer, bytesRead, out encodedLength);

                            byte[] encodedBytes = encodedByteBuffer.Take(encodedLength).ToArray();

                            var audio = new JObject
                            {
                                {"audio",  encodedBytes }
                            };

                            socket.Send(audio);
                        }

                    } while (bytesRead > 0);

                    PrintLine("Sending disconnect");

                    Thread.Sleep(2000);
                    socket.Send(disconnect);
                }
            });

//            socket.On("debug", data =>
//            {
//                PrintLine(data.ToString(), PrintType.SERVER);
//            });

            socket.On(Socket.EVENT_MESSAGE, data =>
            {
                PrintLine(data.ToString(), PrintType.SERVER);

                dynamic resultObject = JObject.Parse(data.ToString());

                string t = resultObject.result[0].alternative[0].transcript.ToString();

                t = t.Trim() + " ";

                File.AppendAllText(audioPath + ".transcript.txt", t);
            });

            socket.On(Socket.EVENT_CONNECT_ERROR, (err) =>
            {
                PrintLine("E R R O R");

                PrintLine(err.ToString());
            });

            socket.On(Socket.EVENT_CONNECT_TIMEOUT, (err) =>
            {
                PrintLine("T I M E O U T");

                PrintLine(err.ToString());
            });

            socket.On(Socket.EVENT_DISCONNECT, (err) =>
            {
                PrintLine("D I S C O N N E C T");

                resetEvent.Set();
            });

            resetEvent.WaitOne();

            socket.Close();

            //Console.ReadLine();
        }

        public static void PrintLine(string str, PrintType type = PrintType.CLIENT)
        {
            Console.WriteLine(type + ": " + str);
        }

        public enum PrintType
        {
            CLIENT,
            SERVER
        }
    }
}